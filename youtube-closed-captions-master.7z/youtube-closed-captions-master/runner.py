from ytcc.download import Download

video_id = 'IZtXVXm8LEQ'
download = Download()
captions = download.get_captions(video_id)
print (captions)